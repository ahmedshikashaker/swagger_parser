import 'package:responsive_builder/responsive_builder.dart';
import 'package:common_dependencies/common_dependencies.dart';
import 'package:kib_design_system/kib_design_system.dart' ;
import 'package:kib_core/kib_core.dart';
import '../cubit/{feature_name_snake}_cubit.dart';


part '{feature_name_snake}_mobile_screen.dart';
part '{feature_name_snake}_web_screen.dart';


class {feature_name_pascal}Screen extends StatelessWidget {
  const {feature_name_pascal}Screen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => getIt<{feature_name_pascal}Cubit>(),
      child: ScreenTypeLayout.builder(
        mobile: (BuildContext context) =>
            const _Mobile{feature_name_pascal}Screen(),
        tablet: (BuildContext context) =>
            const _Web{feature_name_pascal}Screen(),
      ),
    );
  }
}
