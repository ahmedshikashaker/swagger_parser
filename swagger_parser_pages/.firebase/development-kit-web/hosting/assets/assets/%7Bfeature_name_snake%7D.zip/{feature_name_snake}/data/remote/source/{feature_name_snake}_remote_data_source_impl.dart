
import 'package:injectable/injectable.dart';
import '../services/{feature_name_snake}_service.dart';


import '{feature_name_snake}_remote_data_source.dart';

@Injectable(as: {feature_name_pascal}RemoteDataSource)
class {feature_name_pascal}RemoteDataSourceImpl implements {feature_name_pascal}RemoteDataSource {
  final {feature_name_pascal}Service _service;

  const {feature_name_pascal}RemoteDataSourceImpl(this._service);

}
