import 'package:dartz/dartz.dart';
import 'package:injectable/injectable.dart';
import '../remote/source/{feature_name_snake}_remote_data_source.dart';
import '{feature_name_snake}_repository.dart';
import 'package:kib_core/kib_core.dart';


@Injectable(as: {feature_name_pascal}Repository)
class {feature_name_pascal}RepositoryImpl implements {feature_name_pascal}Repository {
  final {feature_name_pascal}RemoteDataSource remoteDataSource;

  const {feature_name_pascal}RepositoryImpl(this.remoteDataSource);

}
