import 'package:built_value/built_value.dart';
import 'package:meta/meta.dart';
import 'package:kib_core/kib_core.dart';


part '{feature_name_snake}_state.freezed.dart';

@freezed
abstract class {feature_name_pascal}State
    with _${feature_name_pascal}State{

  const factory {feature_name_pascal}State.initial() = _Initial;
  const factory {feature_name_pascal}State.loading() = _Loading;
  const factory {feature_name_pascal}State.error(String error) = _Error;
}
