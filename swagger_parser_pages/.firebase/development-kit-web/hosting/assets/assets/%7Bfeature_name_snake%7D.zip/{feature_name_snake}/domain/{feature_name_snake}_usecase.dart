import 'package:dartz/dartz.dart';
import 'package:injectable/injectable.dart';
import 'package:kib_core/kib_core.dart';
import '../data/repository/{feature_name_snake}_repository.dart';



@injectable
class {feature_name_pascal}UseCase{
  final {feature_name_pascal}Repository repository;

  const {feature_name_pascal}UseCase(this.repository);

}
