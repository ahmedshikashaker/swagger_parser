

import 'package:dio/dio.dart';
import 'package:injectable/injectable.dart';
import 'package:retrofit/retrofit.dart';

part '{feature_name_pascal}_service.g.dart';

@RestApi()
@injectable
abstract class {feature_name_pascal}Service{

  @factoryMethod
  factory {feature_name_pascal}Service(Dio dio) = _{feature_name_pascal}Service;



}