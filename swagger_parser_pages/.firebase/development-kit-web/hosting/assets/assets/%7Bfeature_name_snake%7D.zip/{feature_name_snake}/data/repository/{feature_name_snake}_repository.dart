import 'package:dartz/dartz.dart';
import 'package:kib_core/kib_core.dart';


abstract class {feature_name_pascal}Repository {

}
