part of '{feature_name_snake}_screen.dart';


class _Web{feature_name_pascal}Screen extends StatelessWidget {

  const _Web{feature_name_pascal}Screen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      body: AppContainer()
    );
  }
}
