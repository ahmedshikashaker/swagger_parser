
abstract class {feature_name_pascal}RemoteDataSource {

}
