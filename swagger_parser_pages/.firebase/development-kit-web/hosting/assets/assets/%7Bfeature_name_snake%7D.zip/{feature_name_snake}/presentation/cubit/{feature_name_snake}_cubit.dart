import 'dart:async';
import 'package:kib_core/kib_core.dart';
import 'package:common_dependencies/common_dependencies.dart';
import '../../domain/{feature_name_snake}_usecase.dart';
import '{feature_name_snake}_state.dart';

@injectable
class {feature_name_pascal}Cubit extends Cubit<{feature_name_pascal}State> {
  final {feature_name_pascal}UseCase _{feature_name_camel}UseCase;
  
 {feature_name_pascal}Cubit(this._{feature_name_camel}UseCase)
      : super(const {feature_name_pascal}State.initial());

}
