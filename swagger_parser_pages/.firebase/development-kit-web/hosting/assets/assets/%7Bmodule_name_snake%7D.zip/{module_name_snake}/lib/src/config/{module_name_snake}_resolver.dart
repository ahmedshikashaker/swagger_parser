
import 'package:kib_core/kib_core.dart';
import 'package:{module_name_snake}/src/config/router/{module_name_snake}_app_router_module.dart';

import 'di/{module_name_snake}_injection_module.dart';

class {module_name_pascal}Resolver extends FeatureResolver {
  @override
  InjectionModule? get injectionModule => {module_name_pascal}InjectionModule();

  @override
  String? get localizationPath => 'packages/{module_name_snake}/assets/translations';

  @override
  RouterModule? get routerModule => {module_name_pascal}AppRouterModule();
}
