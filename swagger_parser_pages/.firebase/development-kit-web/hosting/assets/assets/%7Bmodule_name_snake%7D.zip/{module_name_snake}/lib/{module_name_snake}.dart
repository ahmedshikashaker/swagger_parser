library {module_name_snake};

export 'package:{module_name_snake}/src/config/{module_name_snake}_resolver.dart';
export 'package:{module_name_snake}/src/config/router/{module_name_snake}_app_router.dart';
export 'package:{module_name_snake}/src/config/router/{module_name_snake}_app_router_module.dart';
export 'package:{module_name_snake}/src/config/di/{module_name_snake}_injection_module.dart';
export 'package:{module_name_snake}/src/config/di/{module_name_snake}_injection_container.dart';