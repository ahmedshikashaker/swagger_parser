import 'package:common_dependencies/common_dependencies.dart';
import 'package:kib_core/kib_core.dart';
import '{module_name_snake}_app_router.dart';

class {module_name_pascal}AppRouterModule extends RouterModule {
  @override
  RootStackRouter get getRouter => {module_name_pascal}AppRouter();
}
