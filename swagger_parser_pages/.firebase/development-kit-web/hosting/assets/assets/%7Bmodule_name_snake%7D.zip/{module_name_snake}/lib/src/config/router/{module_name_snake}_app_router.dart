import 'package:common_dependencies/common_dependencies.dart';
part '{module_name_snake}_app_router.gr.dart';

@MaterialAutoRouter(
  replaceInRouteName: 'Screen,Route',
  routes: <AutoRoute>[],
)
// extend the generated private router
class {module_name_pascal}AppRouter extends _${module_name_pascal}AppRouter {}
