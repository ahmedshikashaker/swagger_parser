import 'package:common_dependencies/common_dependencies.dart';

import '{module_name_snake}_injection_container.config.dart';

@InjectableInit(
  initializerName: r'$init{module_name_pascal}DependenciesGetIt', // default
  preferRelativeImports: true, // default
)
void configure{module_name_pascal}Dependencies(GetIt getIt, String? enviroment) =>
    $init{module_name_pascal}DependenciesGetIt(getIt, environment: enviroment);
