import 'dart:async';
import 'package:common_dependencies/common_dependencies.dart';
import 'package:kib_core/kib_core.dart';

import '{module_name_snake}_injection_container.dart';

class {module_name_pascal}InjectionModule extends InjectionModule {
  @override
  FutureOr<void> registerDependencies(
      {required GetIt injector, required BuildConfig buildConfig}) async {
    configure{module_name_pascal}Dependencies(injector, buildConfig.enviroment);
  }
}
